
	jQuery('.stellarnav').stellarNav({
		theme: 'light',
		breakpoint: 991,
		position: 'right',
	});
